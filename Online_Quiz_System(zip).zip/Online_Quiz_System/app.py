from flask import Flask, render_template, request, redirect, session, flash
from config import get_db_connection

app = Flask(__name__)
app.secret_key = "online_quiz_secret_key"


# ---------------- HOME ---------------- #

@app.route("/")
def home():
    return render_template("index.html")


# ---------------- REGISTER ---------------- #

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        fullname = request.form["fullname"]
        email = request.form["email"]
        password = request.form["password"]

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            "SELECT * FROM users WHERE email=%s",
            (email,)
        )

        user = cursor.fetchone()

        if user:
            flash("Email already registered!")
            cursor.close()
            conn.close()
            return redirect("/register")

        cursor.execute(
            "INSERT INTO users(fullname,email,password) VALUES(%s,%s,%s)",
            (fullname, email, password)
        )

        conn.commit()

        cursor.close()
        conn.close()

        flash("Registration Successful")
        return redirect("/login")

    return render_template("register.html")


# ---------------- LOGIN ---------------- #

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            "SELECT * FROM users WHERE email=%s AND password=%s",
            (email, password)
        )

        user = cursor.fetchone()

        cursor.close()
        conn.close()

        if user:

            session["user_id"] = user["id"]
            session["fullname"] = user["fullname"]

            return redirect("/dashboard")

        flash("Invalid Email or Password")

    return render_template("login.html")


# ---------------- DASHBOARD ---------------- #

@app.route("/dashboard")
def dashboard():

    if "user_id" not in session:
        return redirect("/login")

    return render_template(
        "dashboard.html",
        fullname=session["fullname"]
    )

# ---------------- QUIZ PAGE ---------------- #

@app.route("/quiz")
def quiz():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM questions")
    questions = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "quiz.html",
        questions=questions
    )

# ---------------- SUBMIT QUIZ ---------------- #

@app.route("/submit_quiz", methods=["POST"])
def submit_quiz():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM questions")
    questions = cursor.fetchall()

    score = 0

    for question in questions:

        answer = request.form.get(str(question["id"]))

        if answer == question["correct_answer"]:
            score += 1

    cursor.execute(
        """
        INSERT INTO results(user_id,score,total_questions)
        VALUES(%s,%s,%s)
        """,
        (
            session["user_id"],
            score,
            len(questions)
        )
    )

    cursor.execute(
        """
        UPDATE users
        SET score=%s
        WHERE id=%s
        """,
        (
            score,
            session["user_id"]
        )
    )

    conn.commit()

    cursor.close()
    conn.close()

    flash("Quiz Submitted Successfully!")

    return redirect("/result")


# ---------------- RESULT ---------------- #

@app.route("/result")
def result():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute(
        """
        SELECT *
        FROM results
        WHERE user_id=%s
        ORDER BY id DESC
        LIMIT 1
        """,
        (session["user_id"],)
    )

    result = cursor.fetchone()

    cursor.close()
    conn.close()

    return render_template(
        "result.html",
        result=result
    )


# ---------------- LOGOUT ---------------- #

@app.route("/logout")
def logout():

    session.clear()
    flash("Logged Out Successfully")
    return redirect("/login")

# ---------------- ADMIN LOGIN ---------------- #

@app.route("/admin", methods=["GET", "POST"])
def admin():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            "SELECT * FROM admin WHERE username=%s AND password=%s",
            (username, password)
        )

        admin = cursor.fetchone()

        cursor.close()
        conn.close()

        if admin:

            session["admin"] = admin["username"]
            flash("Admin Login Successful")

            return redirect("/admin_dashboard")

        flash("Invalid Username or Password")

    return render_template("admin_login.html")
# ---------------- ADMIN DASHBOARD ---------------- #

@app.route("/admin_dashboard")
def admin_dashboard():

    if "admin" not in session:
        return redirect("/admin")

    search = request.args.get("search", "")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if search:
        cursor.execute(
            "SELECT * FROM questions WHERE question LIKE %s",
            ("%" + search + "%",)
        )
    else:
        cursor.execute("SELECT * FROM questions")

    questions = cursor.fetchall()

    cursor.execute("SELECT COUNT(*) AS total_users FROM users")
    total_users = cursor.fetchone()["total_users"]

    cursor.execute("SELECT COUNT(*) AS total_questions FROM questions")
    total_questions = cursor.fetchone()["total_questions"]

    cursor.execute("SELECT COUNT(*) AS total_results FROM results")
    total_results = cursor.fetchone()["total_results"]

    cursor.close()
    conn.close()

    return render_template(
        "admin_dashboard.html",
        questions=questions,
        total_users=total_users,
        total_questions=total_questions,
        total_results=total_results,
        search=search
    )

# ---------------- ADD QUESTION ---------------- #

@app.route("/add_question", methods=["GET", "POST"])
def add_question():

    if "admin" not in session:
        return redirect("/admin")

    if request.method == "POST":

        question = request.form["question"]
        option1 = request.form["option1"]
        option2 = request.form["option2"]
        option3 = request.form["option3"]
        option4 = request.form["option4"]
        correct_answer = request.form["correct_answer"]

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO questions
            (question,option1,option2,option3,option4,correct_answer)
            VALUES(%s,%s,%s,%s,%s,%s)
        """,
        (
            question,
            option1,
            option2,
            option3,
            option4,
            correct_answer
        ))

        conn.commit()

        cursor.close()
        conn.close()

        flash("Question Added Successfully")

        return redirect("/admin_dashboard")

    return render_template("add_question.html")

# ---------------- EDIT QUESTION ---------------- #

@app.route("/edit_question/<int:id>", methods=["GET", "POST"])
def edit_question(id):

    if "admin" not in session:
        return redirect("/admin")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":

        question = request.form["question"]
        option1 = request.form["option1"]
        option2 = request.form["option2"]
        option3 = request.form["option3"]
        option4 = request.form["option4"]
        correct_answer = request.form["correct_answer"]

        cursor.execute("""
            UPDATE questions
            SET question=%s,
                option1=%s,
                option2=%s,
                option3=%s,
                option4=%s,
                correct_answer=%s
            WHERE id=%s
        """, (
            question,
            option1,
            option2,
            option3,
            option4,
            correct_answer,
            id
        ))

        conn.commit()

        flash("Question Updated Successfully")

        cursor.close()
        conn.close()

        return redirect("/admin_dashboard")

    cursor.execute(
        "SELECT * FROM questions WHERE id=%s",
        (id,)
    )

    question = cursor.fetchone()

    cursor.close()
    conn.close()

    return render_template(
        "edit_question.html",
        question=question
    )

# ---------------- DELETE QUESTION ---------------- #

@app.route("/delete_question/<int:id>")
def delete_question(id):

    if "admin" not in session:
        return redirect("/admin")

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        "DELETE FROM questions WHERE id=%s",
        (id,)
    )

    conn.commit()

    cursor.close()
    conn.close()

    flash("Question Deleted")

    return redirect("/admin_dashboard")


# ---------------- VIEW USERS ---------------- #

@app.route("/view_users")
def view_users():

    if "admin" not in session:
        return redirect("/admin")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM users")
    users = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("view_users.html", users=users)

# ---------------- LEADERBOARD ---------------- #

@app.route("/leaderboard")
def leaderboard():

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT fullname, score
        FROM users
        ORDER BY score DESC, fullname ASC
        LIMIT 10
    """)

    leaders = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "leaderboard.html",
        leaders=leaders
    )


# ---------------- QUIZ HISTORY ---------------- #

@app.route("/history")
def history():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT score, total_questions
        FROM results
        WHERE user_id=%s
        ORDER BY id DESC
    """, (session["user_id"],))

    history = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "history.html",
        history=history
    )

# ---------------- ADMIN VIEW RESULTS ---------------- #

@app.route("/view_results")
def view_results():

    if "admin" not in session:
        return redirect("/admin")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT
            users.fullname,
            users.email,
            results.score,
            results.total_questions
        FROM results
        INNER JOIN users
        ON users.id = results.user_id
        ORDER BY results.id DESC
    """)

    results = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "view_results.html",
        results=results
    )

# ---------------- RUN APP ---------------- #

if __name__ == "__main__":
    app.run(debug=True)