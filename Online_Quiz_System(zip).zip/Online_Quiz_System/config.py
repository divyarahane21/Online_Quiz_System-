import mysql.connector

def get_db_connection():

    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",      # तुमचा MySQL password लिहा
        database="online_quiz_system"
    )