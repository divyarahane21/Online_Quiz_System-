let timeLeft = 30 * 60; // 30 Minutes

function startTimer() {

    const timer = document.getElementById("timer");

    const interval = setInterval(function () {

        let minutes = Math.floor(timeLeft / 60);
        let seconds = timeLeft % 60;

        if (seconds < 10) {
            seconds = "0" + seconds;
        }

        timer.innerHTML = minutes + ":" + seconds;

        timeLeft--;

        if (timeLeft < 0) {

            clearInterval(interval);

            alert("Time is over! Quiz will be submitted.");

            document.getElementById("quizForm").submit();

        }

    }, 1000);

}

window.onload = startTimer;